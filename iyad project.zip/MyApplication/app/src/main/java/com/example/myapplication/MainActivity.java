package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db=new DatabaseHelper(this);
    static List<Pizza> pizzas;
    ConnectivityManager connectivityManager;
    Button start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        start = (Button)findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Check for Internet Connection first
                //  Collator connectioncheck=null;
                if (connectioncheck.getInstance(getApplicationContext()).isOnline()) {
                    /**
                     * Internet is available, Toast It!
                     */


             //       Cursor cursor=db.getAllUser_();

               //    Toast.makeText(getApplicationContext(),cursor.getCount(), Toast.LENGTH_SHORT).show();


                    ConnectionAsyncTask connectionAsyncTask= new ConnectionAsyncTask(MainActivity.this);
                    connectionAsyncTask.execute("http://www.mocky.io/v2/5ce04a50330000e22c608c09");
//https://www.mocky.io/v2/5185415ba171ea3a00704eed
                    Intent intent  = new Intent(MainActivity.this,SignInAndUp.class);
                    MainActivity.this.startActivity(intent);

                    //Toast.makeText(getApplicationContext(), "WiFi/Mobile Networks Connected!"+ db.getAllUser().get(0).getType(), Toast.LENGTH_SHORT).show();

                    Context context = getApplicationContext();
                    CharSequence text = "The connection is Done!";
                    // int duration = Toast.LENGTH_SHORT;
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                } else {
                    /**
                     * Internet is NOT available, Toast It!
                     */
                    Toast.makeText(getApplicationContext(), "Ooops! No WiFi/Mobile Networks Connected!", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }


    public void fillStudents(List<Pizza> pizza) {

        this.pizzas=pizza;
        DatabaseHelper databaseHelper=new DatabaseHelper(this);
        databaseHelper .dropTables();
       if( !databaseHelper.checkUser("admin@gmail.com") ){
            User user = new User();
            user.setEmail("admin@gmail.com");
            user.setFirstName("Iyad");
            user.setLastName("Omari");
            user.setType("admin");
            user.setGender("Male");
            user.setPassword(md5("1234567a"));
            user.setPhone("0597558753");
            databaseHelper.addUser(user);
        }
        for(int i=0;i<pizza.size();++i){
databaseHelper.addMenu(pizza.get(i));
        }
        pizza=databaseHelper.getAllMenu();
        for(int i =0 ;i<pizza.size();++i){
            databaseHelper.updateMenuId(pizza.get(i).getId());
        }
        Toast.makeText(getApplicationContext(),databaseHelper.getAllMenu().size()+" types of sandwiches", Toast.LENGTH_SHORT).show();
        List list=databaseHelper.getAllUser();

    }
    public String md5(String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            for (int i=0; i<messageDigest.length; i++)
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));

            return hexString.toString();
        }catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }


}