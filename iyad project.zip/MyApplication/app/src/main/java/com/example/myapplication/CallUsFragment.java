package com.example.myapplication;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class CallUsFragment extends Fragment {


    public CallUsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_call_us, container, false);



        Button dialButton = (Button) view.findViewById(R.id.btel);
        dialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent();
                newIntent.setAction(Intent.ACTION_DIAL);
                newIntent.setData(Uri.parse("tel:+0599000000"));
                startActivity(newIntent);
            }
        });


        Button sendButton = (Button)  view.findViewById(R.id.bgmail);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v){
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SENDTO);
                intent.setType("message/rfc822");
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL, "AdvancePizza@Pizza.com");
                intent.putExtra(Intent.EXTRA_SUBJECT, "my subject");
                intent.putExtra(Intent.EXTRA_TEXT, "content of the message");
                startActivity(intent);
            } });
        Button mapButton = (Button)  view.findViewById(R.id.bmap);
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent myIntent = new Intent();
                myIntent.setAction(Intent.ACTION_VIEW);
                myIntent.setData(Uri.parse("geo:31.9074316,35.2085447"));
                startActivity(myIntent); }
        });
        return view;
    }

}
