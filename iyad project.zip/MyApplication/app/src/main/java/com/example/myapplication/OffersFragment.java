package com.example.myapplication;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class OffersFragment extends Fragment {


    public OffersFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_offers, container, false);
        //create object of listview
        final ListView listView=(ListView)view.findViewById(R.id.listviewOffers);

//create ArrayList of String
        final ArrayList<String> arrayList=new ArrayList<>();
        final DatabaseHelper databaseHelper=new DatabaseHelper(getActivity());
        final ArrayList<Pizza> menu=databaseHelper.getAllMenu();
        for(int i=0;i<menu.size();++i){
            if(menu.get(i).getOffer().matches("yes"))
            arrayList.add(menu.get(i).getName());
        }

//Create Adapter
        final ArrayAdapter[] arrayAdapter = {new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, arrayList)};

//assign adapter to listview
        listView.setAdapter(arrayAdapter[0]);

//add listener to listview
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //  databaseHelper.deleteUser(customers.get(i));
                Toast.makeText(getActivity().getApplicationContext(),"clicked item:"+i+" "+arrayList.get(i).toString(),Toast.LENGTH_SHORT).show();
                // customers.remove(i);
                arrayAdapter[0] =new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,arrayList);
                listView.setAdapter(arrayAdapter[0]);
            }
        });

        return view;    }

}
