package com.example.myapplication;


import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;


/**
 * A simple {@link Fragment} subclass.
 */

public class GalleryFragment extends Fragment {
    private  int flagg=0;
    private static final String TAG = "GalleryActivity";
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    private Button btnDisplay;

    public GalleryFragment() {
        // Required empty public constructor
    }

    public void showPopup(View anchorView) {

        final View popupView = getLayoutInflater().inflate(R.layout.popup, null);

        final PopupWindow popupWindow = new PopupWindow(popupView,
                800, 800,true);

        // Example: If you have a TextView inside `popup_layout.xml`
       TextView tv = (TextView) popupView.findViewById(R.id.price);
       Button b = (Button) popupView.findViewById(R.id.confirm);
        DatabaseHelper databaseHelper=new DatabaseHelper(getActivity());

        Pizza pizza=databaseHelper.getMenuByID(Integer.parseInt(CustomerActivity.idOrder));
        String price;
        if(flagg==1) {
            price = pizza.getSmallPrice();
        }
        else if(flagg==2){
            price=pizza.getMediumPrice();
        }
        else{
            price=pizza.getLargePrice();
        }
        tv.setText(price);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


              //  Toast.makeText(getActivity().getApplicationContext(), "pizza now in you faivarite ",Toast.LENGTH_SHORT).show();
               // databaseHelper.addFavourite(user.getId(),Integer.parseInt(CustomerActivity.idOrder));
                DatabaseHelper databaseHelper=new DatabaseHelper(getActivity());

                final User user=databaseHelper.getUser(CustomerActivity.emailRevived);
                databaseHelper.addOrder(user.getId(), Integer.parseInt(CustomerActivity.idOrder));
                 Toast.makeText(getActivity().getApplicationContext(), "pizza now in you cart ",Toast.LENGTH_SHORT).show();

                   popupWindow.dismiss();
            }
        });
        //tv.setText("...............");

        // Initialize more widgets from `popup_layout.xml`


        // If the PopupWindow should be focusable
        popupWindow.setFocusable(true);

        // If you need the PopupWindow to dismiss when when touched outside
        popupWindow.setBackgroundDrawable(new ColorDrawable());

        int location[] = new int[2];

        // Get the View's(the one that was clicked in the Fragment) location
        anchorView.getLocationOnScreen(location);

        // Using location, the PopupWindow will be displayed right under anchorView
        popupWindow.showAtLocation(anchorView, Gravity.CENTER,
                0,0);


    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        final View view= inflater.inflate(R.layout.fragment_gallery, container, false);
        final DatabaseHelper databaseHelper=new DatabaseHelper(getActivity());
        final User user=databaseHelper.getUser(CustomerActivity.emailRevived);
        Log.d(TAG, "onCreate: started.");
        getIncomingIntent(view);
        final Button cart = (Button) view.findViewById(R.id.cart);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                showPopup(view);

            }
        });

        final Button fav = (Button) view.findViewById(R.id.favarite);

        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                databaseHelper.addFavourite(user.getId(),Integer.parseInt(CustomerActivity.idOrder));

                Toast.makeText(getActivity().getApplicationContext(), "pizza now in you faivarite ",Toast.LENGTH_SHORT).show();
            }
        });

        // Inflate the layout for this fragment
        return view;
    }
    private void getIncomingIntent(View view){
        Log.d(TAG, "getIncomingIntent: checking for incoming intents.");

        if(CustomerActivity.imageUrl!=null && CustomerActivity.imageName!=null){
            Log.d(TAG, "getIncomingIntent: found intent extras.");

            String imageUrl = CustomerActivity.imageUrl;
            String imageName =CustomerActivity.imageName;
            String Summary = CustomerActivity.imageSummary;

            setImage(imageUrl, imageName,Summary, view);
        }
    }
    private void getIncomingIntent1(View view){
        Log.d(TAG, "getIncomingIntent: checking for incoming intents.");
        if(CustomerActivity.imageUrl!=null && CustomerActivity.imageName!=null){
            Log.d(TAG, "getIncomingIntent: found intent extras.");
            String imageName =CustomerActivity.imageName;
            setImage1(imageName,view);
        }
    }
    private void setImage1( String imageName,View view){
        Log.d(TAG, "setImage: setting te image and name to widgets.");
        TextView name = view.findViewById(R.id.image_description);
        name.setText(imageName);
        addListenerOnButton(view);
    }

    private void setImage(String imageUrl, String imageName,String summary,View view){
        Log.d(TAG, "setImage: setting te image and name to widgets.");

        TextView name = view.findViewById(R.id.image_description);
        name.setText(imageName);

        ImageView image = view.findViewById(R.id.image);
        Glide.with(this)
                .asBitmap()
                .load(imageUrl)
                .into(image);


        addListenerOnButton(view);

        TextView summary1 = view.findViewById(R.id.Summry);
        summary1.setText(summary);
    }


    public void addListenerOnButton(View view) {

        radioGroup = (RadioGroup) view.findViewById(R.id.radio);

        radioGroup .setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.radio1:
                        flagg=1;
                        // do operations specific to this selection
                        // Toast.makeText(GalleryActivity.this,
                        //  radioButton.getText(), Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radio2:
                        flagg=2;
                        // do operations specific to this selection
                        //  Toast.makeText(GalleryActivity.this,
                        //         radioButton.getText(), Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radio3:
                        flagg=3;
                        // do operations specific to this selection
                        //   Toast.makeText(GalleryActivity.this,
                        //        radioButton.getText(), Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }

}
