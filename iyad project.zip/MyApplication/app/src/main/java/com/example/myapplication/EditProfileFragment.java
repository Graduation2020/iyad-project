package com.example.myapplication;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


/**
 * A simple {@link Fragment} subclass.
 */
public class EditProfileFragment extends Fragment {


    public EditProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final Context contextThemeWrapper = new ContextThemeWrapper(getActivity(), R.style.AppTheme_Dark);

        // clone the inflater using the ContextThemeWrapper
        LayoutInflater localInflater = inflater.cloneInContext(contextThemeWrapper);

        final View view = localInflater.inflate(R.layout.fragment_edit_profile, container, false);
        final DatabaseHelper databaseHelper = new DatabaseHelper(getActivity());
        final EditText firstName = (EditText) view.findViewById(R.id.firstNameFragmentEdit);
        final EditText lastName = (EditText) view.findViewById(R.id.lastNameFragmentEdit);
        final EditText phone = (EditText) view.findViewById(R.id.mobileFragmentEdit);
        final EditText password = (EditText) view.findViewById(R.id.passwordFragmentEdit);

        Toast.makeText(getActivity().getBaseContext(),CustomerActivity.emailRevived, Toast.LENGTH_LONG).show();

User user= databaseHelper.getUser(CustomerActivity.emailRevived);
//        User user=new User();
//        user.setPhone("123");
//        user.setPassword("asdd");
//        user.setFirstName("iyad");
//        user.setLastName("asdadad");
firstName.setText(user.getFirstName());
lastName.setText(user.getLastName());
phone.setText(user.getPhone());
//password.setText(user.getPassword());
        final Button createAccount = (Button) view.findViewById(R.id.button_sgnupFragmentEdit);
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!validate(view)) {

                    return;
                }



                databaseHelper.updateData(CustomerActivity.emailRevived,firstName.getText().toString(),lastName.getText().toString(),md5(password.getText().toString()),phone.getText().toString());
                Toast.makeText(getActivity().getBaseContext(), "Account Updated Successfully!!", Toast.LENGTH_LONG).show();
                HistoryFragment historyFragment=new HistoryFragment();
                FragmentManager fm = getActivity().getSupportFragmentManager();
                fm.beginTransaction().replace(R.id.main,historyFragment).commit();

                // TODO: Implement your own signup logic here.
                String string_to_be_converted_to_MD5 = password.getText().toString();
                String MD5_Hash_String = md5(string_to_be_converted_to_MD5);


            }
        });


        return view;
    }

    public boolean validate(View view) {
        boolean valid = true;

        EditText firstName = (EditText) view.findViewById(R.id.firstNameFragmentEdit);
        EditText lastName = (EditText) view.findViewById(R.id.lastNameFragmentEdit);
        EditText phone = (EditText) view.findViewById(R.id.mobileFragmentEdit);
        EditText password = (EditText) view.findViewById(R.id.passwordFragmentEdit);
        if (firstName.getText().toString().isEmpty() || firstName.getText().toString().length() < 3) {
            firstName.setError("at least 3 characters");
            valid = false;
        } else {
            firstName.setError(null);
        }
        if (lastName.getText().toString().isEmpty() || lastName.getText().toString().length() < 3) {
            lastName.setError("at least 3 characters");
            valid = false;
        } else {
            lastName.setError(null);
        }


        if (phone.getText().toString().isEmpty() || phone.getText().toString().length() != 10 || !phone.getText().toString().startsWith("05")) {
            phone.setError("Enter Valid Mobile Number");
            valid = false;
        } else {
            phone.setError(null);
        }

        if (password.getText().toString().isEmpty() || password.getText().toString().length() < 8 || !(password.getText().toString().matches(".*[0-9].*")) || !(password.getText().toString().matches(".*[A-Z].*") || password.getText().toString().matches(".*[a-z].*"))) {
            password.setError("password must be at least 8 (charcter , numeric)");
            valid = false;
        } else {
            password.setError(null);
        }

        return valid;
    }

    public String md5(String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < messageDigest.length; i++)
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
}

