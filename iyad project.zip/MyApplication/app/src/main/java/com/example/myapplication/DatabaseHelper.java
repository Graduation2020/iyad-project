package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by lalit on 9/12/2016.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Version
int results;

    //private static final String DATABASE_NAME = "UserManager.db";
    // User table name
    private static final String TABLE_USER = "user";

    // User Table Columns names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_FIRST_NAME = "user_first_name";
    private static final String COLUMN_USER_LAST_NAME = "user_last_name";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_USER_PHONE = "user_phone";
    private static final String COLUMN_USER_PASSWORD = "user_password";
    private static final String COLUMN_USER_GENDER = "user_gender";
    private static final String COLUMN_USER_TYPE = "user_type";


    //private static final String TABLE_MENU = "user";

    public static final String TABLE_MENU = "menu";

    public static final String COLUMN_ID = "menu_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_SUMMARY = "summary";
    public static final String COLUMN_SMALL_PRICE = "small_price";
    public static final String COLUMN_MEDIUM_PRICE = "medium_price";
    public static final String COLUMN_LARGE_PRICE = "large_price";
    public static final String COLUMN_OFFER = "offer";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_URL = "url";





    // create table sql query
    private String CREATE_MENU_TABLE = "CREATE TABLE " + TABLE_MENU + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_NAME + " TEXT," +
            COLUMN_SUMMARY + " TEXT," +
            COLUMN_SMALL_PRICE+ " INTEGER," +
            COLUMN_MEDIUM_PRICE+ " INTEGER," +
            COLUMN_LARGE_PRICE+ " INTEGER," +
            COLUMN_OFFER + " TEXT," +
            COLUMN_URL + " TEXT," +
            COLUMN_TYPE+ " TEXT" +")";

    private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_USER_FIRST_NAME + " TEXT," +
            COLUMN_USER_LAST_NAME + " TEXT," +
            COLUMN_USER_EMAIL + " TEXT," +
            COLUMN_USER_PHONE+ " TEXT," +
            COLUMN_USER_PASSWORD + " TEXT," +
            COLUMN_USER_GENDER + " TEXT," +
             COLUMN_USER_TYPE+ " TEXT" +")";


    // drop table sql query



    /**
     * Constructor
     *
     * @param context
     */
    public DatabaseHelper(Context context) {
        super(context, "Pizza_Shop", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_MENU_TABLE);
        String tableOrder="CREATE TABLE orders( customerId  INTEGER, menuId INTEGER, date TEXT, FOREIGN KEY(customerId) REFERENCES user(user_id) , FOREIGN KEY(menuId) REFERENCES menu(menu_id),PRIMARY KEY(customerId,menuId,date))";
        String tableFavourite="CREATE TABLE favourites( customerId  INTEGER, menuId INTEGER, FOREIGN KEY(customerId) REFERENCES user(user_id) , FOREIGN KEY(menuId) REFERENCES menu(menu_id),PRIMARY KEY(customerId,menuId))";

        db.execSQL(tableOrder);
        db.execSQL(tableFavourite);
   }





    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }
    void dropTables(){

        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
       // db.delete(TABLE_USER, null,null);
        db.delete(TABLE_MENU, null,null);
        //db.execSQL("DROP TABLE menu");
        //db.execSQL(CREATE_MENU_TABLE);
        db.close();

    }

    /**
     * This method is to create user record
     *
     * @param user
     */


    public boolean addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_FIRST_NAME, user.getFirstName());
        values.put(COLUMN_USER_LAST_NAME, user.getLastName());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PHONE, user.getPhone());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());
        values.put(COLUMN_USER_GENDER, user.getGender());
        values.put(COLUMN_USER_TYPE, user.getType());

        // Inserting Row

        long result = db.insert(TABLE_USER, null, values);

        if(results == -1)
            return false;
        else
            return true;
    }


    public boolean addMenu (Pizza pizza){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, pizza.getName());
        values.put(COLUMN_SUMMARY, pizza.getSummary());
        values.put(COLUMN_SMALL_PRICE, pizza.getSmallPrice());
        values.put(COLUMN_MEDIUM_PRICE, pizza.getMediumPrice());
        values.put(COLUMN_LARGE_PRICE, pizza.getLargePrice());
        values.put(COLUMN_OFFER, pizza.getOffer());
        values.put(COLUMN_TYPE, pizza.getType());
        values.put(COLUMN_URL,pizza.getUrl());
        // Inserting Row
        long result = db.insert(TABLE_MENU, null, values);
        if(results == -1)
            return false;
        else
            return true;
    }
    /**
     * This method is to fetch all user and return the list of user records
     *
     * @return list
     */
    public Cursor getAllUser_(){
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER
        };
        // sorting orders
        String sortOrder =
                COLUMN_USER_FIRST_NAME + " ASC";
        List<User> userList = new ArrayList<User>();

        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order

        return cursor;
    }
    public Pizza getMenuByID(int id){

        String[] columns = {
                COLUMN_ID,
                COLUMN_TYPE,
                COLUMN_NAME,
                COLUMN_SUMMARY,
                COLUMN_SMALL_PRICE,
                COLUMN_MEDIUM_PRICE,
                COLUMN_LARGE_PRICE,
                COLUMN_TYPE,
                COLUMN_OFFER,
                COLUMN_URL
        };



        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_ID + " = ?";

        // selection arguments
        String[] selectionArgs = {id+""};
        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_MENU, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order
    if(cursor.moveToFirst()) {
        Pizza pizza = new Pizza();

        pizza.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ID))));
        pizza.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
        pizza.setSummary(cursor.getString(cursor.getColumnIndex(COLUMN_SUMMARY)));
        pizza.setLargePrice(cursor.getString(cursor.getColumnIndex(COLUMN_LARGE_PRICE)));
        pizza.setMediumPrice(cursor.getString(cursor.getColumnIndex(COLUMN_MEDIUM_PRICE)));
        pizza.setSmallPrice(cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PRICE)));
        pizza.setType(cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)));
        pizza.setOffer(cursor.getString(cursor.getColumnIndex(COLUMN_OFFER)));
        pizza.setUrl(cursor.getString(cursor.getColumnIndex(COLUMN_URL)));
        return pizza;
    }


        return null;
    }
    public ArrayList<Pizza> getAllMenu(){
        ArrayList<Pizza> menu=new ArrayList<Pizza>();
        String[] columns = {
                COLUMN_ID,
                COLUMN_TYPE,
                COLUMN_NAME,
                COLUMN_SUMMARY,
                COLUMN_SMALL_PRICE,
                COLUMN_MEDIUM_PRICE,
                COLUMN_LARGE_PRICE,
                COLUMN_TYPE,
                COLUMN_OFFER,
                COLUMN_URL
        };
        // sorting orders
        String sortOrder =
                COLUMN_NAME + " ASC";
        List<Pizza> pizzaList = new ArrayList<Pizza>();

        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_MENU, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order
        if (cursor.moveToFirst()) {
            do {
                Pizza pizza=new Pizza();

                pizza.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ID))));
                pizza.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                pizza.setSummary(cursor.getString(cursor.getColumnIndex(COLUMN_SUMMARY)));
                pizza.setLargePrice(cursor.getString(cursor.getColumnIndex(COLUMN_LARGE_PRICE)));
                pizza.setMediumPrice(cursor.getString(cursor.getColumnIndex(COLUMN_MEDIUM_PRICE)));
                pizza.setSmallPrice(cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PRICE)));
                pizza.setType(cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)));
                pizza.setOffer(cursor.getString(cursor.getColumnIndex(COLUMN_OFFER)));
                pizza.setUrl(cursor.getString(cursor.getColumnIndex(COLUMN_URL)));


                menu.add(pizza);
            } while (cursor.moveToNext());
        }
       return menu;

    }

    public List<User> getAllUser() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        // sorting orders
        String sortOrder =
                COLUMN_USER_FIRST_NAME + " ASC";
        List<User> userList = new ArrayList<User>();

        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
                user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
                user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return userList;
    }

    /**
     * This method to update user record
     *
     * @param user
     */
    public void updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_FIRST_NAME, user.getFirstName());
        values.put(COLUMN_USER_LAST_NAME, user.getLastName());
        values.put(COLUMN_USER_PHONE, user.getPhone());

        values.put(COLUMN_USER_PASSWORD, user.getPassword());
        // updating row
        db.update(TABLE_USER, values, COLUMN_USER_EMAIL + " = ?",
                new String[]{});
        db.close();
    }

    public boolean updateData(String email, String firstName, String lastName, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USER_PASSWORD,password);
        contentValues.put(COLUMN_USER_PHONE,phone);
        contentValues.put(COLUMN_USER_FIRST_NAME,firstName);
        contentValues.put(COLUMN_USER_LAST_NAME,lastName);

        db.update(TABLE_USER, contentValues, COLUMN_USER_EMAIL+ " = ?",new String[] { email });
        return true;

    }

    public void updatePassword(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_PASSWORD, password);
        db.update(TABLE_USER, values, COLUMN_USER_EMAIL+" = ?",new String[] { email });
        db.close();
    }
    /**
     * This method is to delete user record
     *
     * @param user
     */
    public void deleteUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(TABLE_USER, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }
    public Integer deleteuserData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_USER, COLUMN_USER_ID + " = ?",new String[] {id});
    }

    /**
     * This method to check user exist or not
     *
     * @param email
     * @return true/false
     */
    public boolean checkUser(String email) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection argument
        String[] selectionArgs = {email};

        // query user table with condition
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com';
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    /**
     * This method to check user exist or not
     *
     * @param email
     * @param password
     * @return true/false
     */

    public boolean checkUser(String email, String password) {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_PASSWORD + " = ?";

        // selection arguments
        String[] selectionArgs = {email, password};

        // query user table with conditions
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com' AND user_password = 'qwerty';
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean userType(String email,String type) {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_TYPE + " = ?";

        // selection arguments
        String[] selectionArgs = {email,type};

        // query user table with conditions
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com' AND user_password = 'qwerty';
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }
    public boolean addOrder(int customerId,int menuId){
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String dateTime=dateFormat.format(date);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("customerId", customerId);
        values.put("menuId", menuId);
        values.put("date", dateTime);

        // Inserting Row

        long result = db.insert("orders", null, values);

        if(results == -1)
            return false;
        else
            return true;



    }

    public User getUserById(int id) {
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        String selection = COLUMN_USER_ID + " = ?";

        // selection arguments
        String[] selectionArgs = {id+""};




        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if( cursor.moveToFirst()) {

            User user = new User();
            user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
            user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
            user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
            user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
            user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
            user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
            user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));

            cursor.close();
            db.close();

            // return user list
            return user;
        }
        return null;

    }
    public User getUser(String emailRevived) {
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection arguments
        String[] selectionArgs = {emailRevived};




        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        cursor.moveToFirst();
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
                user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
                user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));

        cursor.close();
        db.close();

        // return user list
        return user;

    }
    public ArrayList<Order> getOrders(){
        ArrayList<Order> orders =new ArrayList<Order>();
        // array of columns to fetch
        String[] columns = {
   "customerId",
                "menuId",
                "date"

        };



        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query("orders", //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order



        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Order order = new Order();
                order.setCustomerId(Integer.parseInt(cursor.getString(cursor.getColumnIndex("customerId"))));
                order.setMenuId(Integer.parseInt(cursor.getString(cursor.getColumnIndex("menuId"))));
                order.setDate(cursor.getString(cursor.getColumnIndex("date")));

                // Adding user record to list
                orders.add(order);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return orders;

    }
    public boolean addFavourite(int customerId,int menuId){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("customerId", customerId);
        values.put("menuId", menuId);


        // Inserting Row

        long result = db.insert("favourites", null, values);

        if(results == -1)
            return false;
        else
            return true;


    }

    public ArrayList<Pizza> favourite(int idUser) {

        ArrayList<Pizza> favouriteList = new ArrayList<Pizza>();

        String customerId="customerId";
        String menuId="menuId";
        String[] columns = {
                customerId,
                menuId
        };
        String selection = customerId + " = ?";

        // selection arguments
        String[] selectionArgs = {idUser+""};



        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query("favourites", //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order



        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                if(Integer.parseInt(cursor.getString(cursor.getColumnIndex("customerId"))) == idUser) {

                    Pizza pizza =this.getMenuByID(Integer.parseInt(cursor.getString(cursor.getColumnIndex("menuId"))));

                    favouriteList.add(pizza);
                }
            } while (cursor.moveToNext());

        }
        return favouriteList;
    }

    public ArrayList<User> getAllCustomers() {
        ArrayList<User> userList=new ArrayList<User>();
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        String selection = COLUMN_USER_TYPE + " = ?";

        // selection arguments
        String[] selectionArgs = {"customer"};




        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
                user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
                user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return userList;
    }

    public void updateMenuId(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int newId=id%10;
        if(newId==0)
            newId=10;
        values.put(COLUMN_ID, newId);

        db.update(TABLE_MENU, values, COLUMN_ID+" = ?",new String[] { id+"" });
        db.close();
    }

    public ArrayList<Pizza> search(String  price, String size, String category) {
        ArrayList<Pizza> menu=new ArrayList<Pizza>();
        String[] columns = {
                COLUMN_ID,
                COLUMN_TYPE,
                COLUMN_NAME,
                COLUMN_SUMMARY,
                COLUMN_SMALL_PRICE,
                COLUMN_MEDIUM_PRICE,
                COLUMN_LARGE_PRICE,
                COLUMN_TYPE,
                COLUMN_OFFER,
                COLUMN_URL
        };
        // sorting orders
        String sortOrder =
                COLUMN_NAME + " ASC";
        List<Pizza> pizzaList = new ArrayList<Pizza>();

        SQLiteDatabase db = this.getReadableDatabase();


        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        String selection;
        String[] selectionArgs;
        if(price!=null) {
          if(size.matches("all")){
              if(category.matches("all")){
                  selection=COLUMN_MEDIUM_PRICE + " <= ?";
                  selectionArgs= new String[]{price};
              }
              else {
                  selection=COLUMN_MEDIUM_PRICE + " <= ? and "+COLUMN_TYPE+ " =?" ;
                  selectionArgs= new String[]{price,category};
              }
          }
          else{
              if(category.matches("all")){
                  selection=COLUMN_MEDIUM_PRICE + " <= ?and "+COLUMN_TYPE+ " =?";
                  selectionArgs= new String[]{price};
              }
              else {
                  selection=COLUMN_MEDIUM_PRICE + " <= ? and "+COLUMN_TYPE+ " =?" ;
                  selectionArgs= new String[]{price,category};
              }

          }
        }
        else{
            if(size.matches("all")){
                if(category.matches("all")){

                }
                else {

                }
            }
            else{

            }
        }



        Cursor cursor = db.query(TABLE_MENU, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order
        if (cursor.moveToFirst()) {
            do {
                Pizza pizza=new Pizza();

                pizza.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ID))));
                pizza.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                pizza.setSummary(cursor.getString(cursor.getColumnIndex(COLUMN_SUMMARY)));
                pizza.setLargePrice(cursor.getString(cursor.getColumnIndex(COLUMN_LARGE_PRICE)));
                pizza.setMediumPrice(cursor.getString(cursor.getColumnIndex(COLUMN_MEDIUM_PRICE)));
                pizza.setSmallPrice(cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PRICE)));
                pizza.setType(cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)));
                pizza.setOffer(cursor.getString(cursor.getColumnIndex(COLUMN_OFFER)));
                pizza.setUrl(cursor.getString(cursor.getColumnIndex(COLUMN_URL)));


                menu.add(pizza);
            } while (cursor.moveToNext());
        }
        return menu;
    }
}
