package com.example.myapplication;

import android.support.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mohammad on 7/30/2017.
 */

public class StudentJasonParser {

    @Nullable
    public static List<Pizza> getObjectFromJason(String jason) {
        List<Pizza> Pizzaa;
        try {
            JSONArray jsonArray = new JSONArray(jason);
            Pizzaa = new ArrayList<>();
            for(int i = 0; i<jsonArray.length(); i++)
            {
                JSONObject jsonObject;
                jsonObject= (JSONObject) jsonArray.get(i);
                Pizza pizza = new Pizza();
                pizza.setName(jsonObject.getString("name"));
                pizza.setSummary(jsonObject.getString("summary"));
                pizza.setType(jsonObject.getString("type"));
                pizza.setSmallPrice(jsonObject.getString("smallPrice"));
                pizza.setMediumPrice(jsonObject.getString("medium"));
                pizza.setLargePrice(jsonObject.getString("largePrice"));
                pizza.setOffer(jsonObject.getString("offer"));
                pizza.setUrl(jsonObject.getString("url"));
                System.out.printf(pizza.toString()+"\n");


                Pizzaa.add(pizza);
            }
        } catch (JSONException e)
        { e.printStackTrace();
            return null;
        }

        return Pizzaa;
    }
}
