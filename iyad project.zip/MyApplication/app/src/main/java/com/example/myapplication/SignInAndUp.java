package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SignInAndUp extends AppCompatActivity {
    @BindView(R.id.login)
    Button _signin;
    @BindView(R.id.singup)
    Button _signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_and_up);
        ButterKnife.bind(this);
       _signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(SignInAndUp.this,LoginActivity.class);
                SignInAndUp.this.startActivity(intent);
                //Toast.makeText(getApplicationContext(), "data is saved",Toast.LENGTH_SHORT).show();


            }
        });
        _signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(SignInAndUp.this,SignupActivity.class);
                SignInAndUp.this.startActivity(intent);

            }
        });
    }
}
