package com.example.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;


public class Menu_rec_view extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    //vars
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    private ArrayList<String> summry = new ArrayList<>();
    private ArrayList<String> id=new ArrayList<>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_recview);
        Log.d(TAG, "onCreate: started.");
        initImageBitmaps();
    }







    private void initImageBitmaps(){
        ArrayList<Pizza> list=new ArrayList<>();
        DatabaseHelper databaseHelper=new DatabaseHelper(this);
        if(CustomerActivity.flag==1) {
           list = databaseHelper.getAllMenu();
        }
        else if(CustomerActivity.flag==2){
            ArrayList<Pizza> listTemp = databaseHelper.getAllMenu();
for(int i=0; i< listTemp.size();++i){
    if(listTemp.get(i).getOffer().matches("yes"))
        list.add(listTemp.get(i));
}
        }
        else{

            User user=databaseHelper.getUser(CustomerActivity.emailRevived);
           list= databaseHelper.favourite(user.getId());

        }

        Log.d(TAG, "initImageBitmaps: preparing bitmaps.");
        for(int i=0;i<list.size();++i) {
            mImageUrls.add(list.get(i).getUrl());
            mNames.add(list.get(i).getName());
            summry.add(list.get(i).getSummary());
            id.add(list.get(i).getId()+"");
        }

        initRecyclerView();
    }

    private void initRecyclerView(){
        Log.d(TAG, "initRecyclerView: init recyclerview.");
        RecyclerView recyclerView = findViewById(R.id.recyclerv_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(Menu_rec_view.this, mNames, mImageUrls,summry,id);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}


















